# pivotaltracker-numerical-snippet
pivotal tracker numerical integration 
